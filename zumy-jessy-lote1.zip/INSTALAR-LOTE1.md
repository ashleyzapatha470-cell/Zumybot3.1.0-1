# Zumybot · Comandos da Jessy, lote 1

## Instalação

1. Extraia este ZIP e baixe uma cópia atual do repositório Zumybot3.1.0.
2. No computador, com Node.js instalado, rode `node /caminho/aplicar-lote1.mjs /caminho/Zumybot3.1.0 --check` para validar a estrutura. Em seguida, rode o mesmo comando sem `--check`.
3. Envie somente `jogos.js` e `menu.js` atualizados para a branch `main` do GitHub e publique o último commit no Render.
4. Abra `!menu jogos` ou `!menu zoeiras`. Teste `!moeda` e `!escolher pizza | açaí`.

## Comandos do lote

| Comando | Resultado |
|---|---|
| `!moeda` | Sorteia cara ou coroa. |
| `!slot` | Sorteia três símbolos de brincadeira. |
| `!velha` | Abre uma rodada individual contra a Zumy. Use `!velha cancelar` para encerrar. |
| `!jogar 5` | Joga na casa 5 da rodada de jogo da velha. |
| `!bola8 Vou ganhar hoje?` | Sorteia uma resposta. |
| `!chance Vou ganhar hoje?` | Sorteia uma porcentagem de brincadeira. |
| `!escolher pizza \| açaí` | Escolhe entre as opções informadas. |
| `!piada` | Conta uma piada curta. |
| `!vibe` | Sorteia uma vibe. |
| `!superpoder` | Sorteia um superpoder. |
| `!animal` | Sorteia um animal. |
| `!futuro` | Gera uma previsão de brincadeira. |
| `!vidapassada` | Conta uma história inventada. |
| `!frase` | Envia uma frase curta. |
| `!conselho` | Sorteia um conselho cotidiano. |

A comparação incluiu o código da Zumy disponível e o guia v10. Funções equivalentes já aparecem na Zumy: `!ppt` corresponde a `!pedra`, `!papel` e `!tesoura`; `!vd` corresponde a `!verdadeoudesafio`; `!chute` faz parte de `!adivinhar`; `!palavra` pode ser usado como palpite dentro de `!forca`; `!todos` corresponde a `!marcar`; `!apagar` a `!del`; `!abrir` e `!fechar` a `!abrirgp` e `!fechargp`. A economia, a família, as utilidades e os downloads novos ficam para lotes posteriores.

A aplicação foi testada localmente sobre a cópia disponível do código da Zumy. Se o script achar um comando repetido ou um menu com formato diferente, confira os arquivos atuais antes de publicar.
