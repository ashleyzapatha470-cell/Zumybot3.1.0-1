import { readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const folder = resolve(process.argv[2] || '.');
const gamesPath = resolve(folder, 'jogos.js');
const menuPath = resolve(folder, 'menu.js');
const [games, menu] = await Promise.all([readFile(gamesPath, 'utf8'), readFile(menuPath, 'utf8')]);

const novo = {
  JOGOS: ['moeda', 'slot', 'velha', 'jogar'],
  ZOEIRAS: ['bola8', 'chance', 'escolher', 'piada', 'vibe', 'superpoder', 'animal', 'futuro', 'vidapassada', 'frase', 'conselho'],
};
for (const name of Object.values(novo).flat()) {
  if (new RegExp('\\b' + name + '\\s*:').test(games) || new RegExp('(?:^|[|\x27])' + name + '(?:[|\x27]|$)', 'm').test(menu)) {
    throw new Error('Encontrei !' + name + ' no projeto. Confira com o arquivo atual para evitar duplicação.');
  }
}

const marker = '  return {\n    jogos:';
if (games.split(marker).length !== 2 || !games.includes('const rounds = new Map();')) {
  throw new Error('Estrutura de jogos.js diferente da versão prevista. Nenhum arquivo foi alterado.');
}

const helpers = String.raw`  const linhasVelha = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
  const ganhador = tabuleiro => linhasVelha.find(([a,b,c]) =>
    tabuleiro[a] && tabuleiro[a] === tabuleiro[b] && tabuleiro[b] === tabuleiro[c]);
  const tabuleiroTexto = tabuleiro => [0,3,6].map(offset =>
    tabuleiro.slice(offset, offset + 3).map((p, i) => p || String(offset + i + 1)).join(' │ ')).join('\n');

  function velha({ jid, actor, arg, reply }, alias = false) {
    if (!actor) return reply('Não consegui identificar seu jogador.');
    const rodada = get(jid, 'velha:' + actor);
    const input = normalize(arg);
    if (input === 'cancelar') {
      rodada.clear();
      return reply('Jogo da velha encerrado.');
    }
    if (!alias && (!input || input === 'iniciar')) {
      const board = rodada.current || Array(9).fill('');
      rodada.set(board);
      return reply('⭕ Você é X. Digite !jogar 1 a 9.\n\n' + tabuleiroTexto(board));
    }
    if (!rodada.current || !/^[1-9]$/.test(input)) {
      return reply('Use !velha para abrir o tabuleiro e !jogar 1 a 9 para marcar.');
    }
    const board = rodada.current;
    const i = Number(input) - 1;
    if (board[i]) return reply('Casa ocupada.\n' + tabuleiroTexto(board));
    board[i] = 'X';
    let result = ganhador(board) ? '🎉 Você ganhou!' : '';
    if (!result && board.includes('')) {
      const livres = board.flatMap((p, index) => p ? [] : [index]);
      const finaliza = p => livres.find(index => {
        const teste = [...board];
        teste[index] = p;
        return Boolean(ganhador(teste));
      });
      const bot = finaliza('O') ?? finaliza('X') ?? pick(livres);
      board[bot] = 'O';
      if (ganhador(board)) result = '🤖 A Zumy ganhou!';
    }
    if (!result && !board.includes('')) result = '🤝 Empate!';
    if (result) rodada.clear();
    return reply(tabuleiroTexto(board) + '\n\n' + (result || 'Sua vez. Use !jogar 1 a 9.'));
  }

`;

const handlers = String.raw`    moeda: ({ reply }) => reply('🪙 ' + pick(['Cara', 'Coroa'])),
    slot: ({ reply }) => {
      const reels = Array.from({ length: 3 }, () => pick(['🍒', '🍋', '⭐', '💎', '🍇']));
      const matches = new Set(reels).size;
      return reply('🎰 ' + reels.join(' │ ') + '\n' +
        (matches === 1 ? 'Trinca! 🎉' : matches === 2 ? 'Você tirou um par!' : 'Tente outra rodada.'));
    },
    velha: context => velha(context),
    jogar: context => velha(context, true),
    bola8: ({ arg, reply }) => arg
      ? reply('🎱 ' + pick(['Sim!', 'Acho que sim.', 'Ainda é cedo para dizer.', 'Pergunte de novo depois.', 'Acho que não.']))
      : reply('Use !bola8 PERGUNTA. Exemplo: !bola8 vou ganhar o próximo jogo?'),
    chance: ({ arg, reply }) => arg
      ? reply('🎲 Chance sorteada: ' + randomInt(101) + '% · brincadeira.')
      : reply('Use !chance PERGUNTA. Exemplo: !chance vou ganhar hoje?'),
    escolher: ({ arg, reply }) => {
      const items = [...new Set(arg.split(/\s*\|\s*|\s+ou\s+/i).map(item => item.trim()).filter(Boolean))];
      if (items.length < 2 || items.length > 12 || items.some(item => item.length > 120)) {
        return reply('Use !escolher OPÇÃO A | OPÇÃO B. Informe de 2 a 12 opções curtas.');
      }
      return reply('✨ Eu escolho: ' + pick(items));
    },
    piada: ({ reply }) => reply('😂 ' + pick([
      'Por que o livro de matemática ficou triste? Porque tinha muitos problemas.',
      'O que a impressora falou para a outra? Essa folha é sua ou é impressão minha?',
      'Por que o computador foi ao médico? Porque pegou um vírus.',
    ])),
    vibe: ({ reply }) => reply('✨ Sua vibe sorteada: ' + pick(['playlist no fim da tarde', 'maratona de risadas', 'café com fofoca leve', 'modo aventura'])),
    superpoder: ({ reply }) => reply('⚡ Seu poder sorteado: ' + pick(['teletransporte', 'falar com os animais', 'parar o tempo', 'achar o carregador certo na primeira tentativa'])),
    animal: ({ reply }) => reply('🐾 Animal sorteado: ' + pick(['capivara tranquila', 'raposa curiosa', 'coruja observadora', 'lontra brincalhona'])),
    futuro: ({ reply }) => reply('🔮 Previsão de brincadeira: ' + pick(['uma conversa vai render risada', 'você vai descobrir uma música nova', 'logo alguém vai mandar um meme perfeito'])),
    vidapassada: ({ reply }) => reply('🌙 História inventada: numa vida passada você ' + pick([
      'cuidava de uma biblioteca à beira-mar.', 'viajava com um circo de gatos.', 'criava mapas de ilhas imaginárias.',
    ])),
    frase: ({ reply }) => reply('💬 ' + pick(['Uma conversa boa melhora o dia.', 'Comece pelo que dá para fazer hoje.', 'Descansar também faz parte.'])),
    conselho: ({ reply }) => reply('🌷 ' + pick(['Se o dia estiver pesado, faça uma pausa.', 'Pergunte antes de tirar conclusões.', 'Dê atenção a quem também dá atenção a você.'])),
`;

let novoMenu = menu;
for (const [section, commands] of Object.entries(novo)) {
  const re = new RegExp("(\\['" + section + "',\\s*'[^']*',\\s*')([^'\\r\\n]+)('\\])", 'g');
  const matches = [...novoMenu.matchAll(re)];
  if (matches.length !== 1) throw new Error('Não encontrei a seção ' + section + '. Nenhum arquivo foi alterado.');
  novoMenu = novoMenu.replace(re, (_m, before, values, after) => before + values + '|' + commands.join('|') + after);
}
const novoJogo = games.replace(marker, () => helpers + '  return {\n' + handlers + '    jogos:');
if (process.argv.includes('--check')) {
  console.log('Compatível. Nenhum arquivo foi alterado.');
} else {
  await writeFile(gamesPath, novoJogo);
  await writeFile(menuPath, novoMenu);
  console.log('15 comandos adicionados em jogos.js e menu.js. Confira as alterações antes do deploy.');
}
